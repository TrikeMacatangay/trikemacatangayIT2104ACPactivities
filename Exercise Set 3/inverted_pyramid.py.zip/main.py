def inverted_half_pyramid(n):
    for i in range(n, 0, -1):
        print('* ' * i)

rows = 5  
inverted_half_pyramid(rows)
